
#include <stdio.h>

int main()
{
    int opcao;
    int num1;
    int num2;
    int result;
    printf("Digite o primeiro número: ");
    scanf("%d",&num1 );
    printf("Digite o segundo número: ");
    scanf("%d",&num2 );
    printf("Opções: \n");
    printf("1 - Somar\n");
    printf("2 - subtrair\n");
    printf("3 - multiplicar\n");
    printf("4 - dividir\n");
    printf("0 - sair\n");
    scanf("%d",&opcao);
    switch(opcao){
        case 1:
            result = num1 + num2;
            printf("%d",result);
            break;
        case 2:
            result = num1 - num2;
            printf("%d",result);
            break;
        case 3:
            result = num1 * num2;
            printf("%d",result);
            break;
        case 4:
            result = num1 / num2;
            printf("%d",result);
            break;
        case 0:
            break;
            
    }

    return 0;
}
