
#include <stdio.h>

int main()
{
    float altura, idade;
    float somaIdade,somaAltura;
    float mediaIdade, mediaAltura;
   
    
    for(int i =  1; i<= 3; i++){
    do{
    printf("Digite a altura do %d° aluno: ",i);
    scanf("%f",&altura);
    }
    while(altura < 0.4);
    if(altura < 1.70){
        somaAltura += altura;
    }
    do{
    printf("Digite a idade do %d° aluno: ",i);
    scanf("%f", &idade);
    }
    while(idade < 0);
    if(idade > 20){
        somaIdade += altura;
    }
}
    mediaIdade = somaIdade/45;
    mediaAltura = somaAltura/45;

     printf(" A média das alturas dos alunos menores que 1.70 são: %.2f\n",mediaAltura);
     printf(" A média das idades dos alunos  com mais de 20 anos são: %.2f",mediaIdade);
    return 0;
}
