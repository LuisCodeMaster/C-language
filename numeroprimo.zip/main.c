#include <stdio.h>

int main() {
  int i, numero;
  int contadorDivisores = 0;
  do {
    printf("Digite um número maior que 1: ");
    scanf("%d", &numero);
  }
    while (numero < 2);

    for (int i = 1; i <= numero; i++) {
      if (numero % i == 0) {
        contadorDivisores += 1;
      }
    }
    if (contadorDivisores > 2) {
      printf("Este %d número não é primo", numero);
    } else {
      printf("Esse %d número é primo", numero);
    }
  
  return 0;
}