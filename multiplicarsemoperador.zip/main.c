/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b,resultado;
    int contador;
    int opcao;
    do{
    printf("Digite o primeiro numero: ");
    scanf("%d",&a);
    printf("Digite o segundo numero: ");
    scanf("%d",&b);
   
    for(contador = 1; contador<=a; contador++)
        resultado = resultado + b;
    printf("%d",resultado);
    
    
        printf("\n(1) para fazer para fazer outra operecao\n(0) para encerrar...\n");
        scanf("%d",&opcao);
    }
    while(opcao==1);
    printf("Thank you!!");
    return 0;
}
