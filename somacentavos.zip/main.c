/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i;
    int valorFinal = 0, valorInicial = 1;
    for(int i = 1; i<=30; i++)
        valorInicial = valorInicial*2;
        valorFinal =  valorInicial;
    printf("O total guardado foi de: R$ %.2f",valorFinal/100.0);

    return 0;
}
