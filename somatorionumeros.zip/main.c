
#include <stdio.h>

int main()
{
    int n;
    int somatorio;
    somatorio = 0;
    printf("Digite um número: ");
    scanf("%d",&n);
    
    for(int i = 1; i<=n; i++)
        somatorio = somatorio + n;
        
        printf("somatorio dos números: %d",somatorio);

    return 0;
}
